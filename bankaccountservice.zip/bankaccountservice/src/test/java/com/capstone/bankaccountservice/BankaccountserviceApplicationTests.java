package com.capstone.bankaccountservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankaccountserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
