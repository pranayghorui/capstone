package com.capstone.bankaccountservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankaccountserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankaccountserviceApplication.class, args);
	}

}
