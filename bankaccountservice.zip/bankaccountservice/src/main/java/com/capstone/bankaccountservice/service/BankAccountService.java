package com.capstone.bankaccountservice.service;

import java.util.List;

import com.capstone.bankaccountservice.entity.BankAccount;

public interface BankAccountService {

	void createBankAccount(BankAccount bankAccount);
	
	List<BankAccount> findAll();
	
	BankAccount getById(int id);
	
	void deleteById(int id);
	
	List<BankAccount> getBankAcOfUserId(int userId);
	
//	BankAccount getByUserAcId(String userAcId);
	
}
