package com.capstone.usersrevice.service.impl;

import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstone.usersrevice.entity.User;
import com.capstone.usersrevice.repo.UserRepo;
import com.capstone.usersrevice.service.BankClient;
import com.capstone.usersrevice.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo userRepo;
	
	@Autowired
	private BankClient bankClient;
	
	public UserServiceImpl(UserRepo userRepo, BankClient bankClient) {
		super();
		this.userRepo = userRepo;
		this.bankClient = bankClient;
	}
	
	@Override
	public void createUser(User user) {
		userRepo.save(user);
	}

	@Override
	public List<User> findAll() {
		List<User> users = userRepo.findAll();
		List<User> newUsersList = users.stream().map (user -> {
			user.setBankAccounts(bankClient.getBankAccountOfUserId(user.getId()));
			return user;
		}).collect(Collectors.toList());
		
		return newUsersList;
	}

	@Override
	public User getById(int id) {
		User user = userRepo.findById(id).get();
		user.setBankAccounts(bankClient.getBankAccountOfUserId(user.getId()));
		return user;
	}

	@Override
	public void deleteById(int id) {
		userRepo.deleteById(id);
	}

	@Override
	public User getByUserAcId(String userAcId) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public User getByUserAcId(String userAcId) {
//		return userRepo.getByUserAcId(userAcId);
//	}
	
	

}
