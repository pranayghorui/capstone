package com.capstone.usersrevice.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table (name="userdetails")
public class User {

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(name="uname")
	private String name;
	@Column(name="uaddress")
	private String address;
	@Column(name="useracid")
	private String userAcId;
	
	transient private List<BankAccount> bankAccounts;
	
	public List<BankAccount> getBankAccounts() {
		return bankAccounts;
	}
	public void setBankAccounts(List<BankAccount> bankAccounts) {
		this.bankAccounts = bankAccounts;
	}
	public String getUserAcId() {
		return userAcId;
	}
	public void setUserAcId(String userAcId) {
		this.userAcId = userAcId;
	}
	
	public User(int id, String name, String address, String userAcId) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.userAcId = userAcId;
	}
	public User() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", address=" + address + ", userAcId=" + userAcId + "]";
	}
//	public void setAddress(List<BankAccount> bankAccountOfUserId) {
//		// TODO Auto-generated method stub
//		
//	}
	
	
}
