package com.capstone.usersrevice.entity;

public class BankAccount {

	private int id;
	private String accountNumber;
	private String accountType;
	private int userId;
	public BankAccount() {
		super();
	}
	
	public BankAccount(int id, String accountNumber, String accountType, int userId) {
		this.id = id;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.userId = userId;
//		this.userAcId = userAcId;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "BankAccount [id=" + id + ", accountNumber=" + accountNumber + ", accountType=" + accountType
				+ ", userId=" + userId + "]";
	}

}
