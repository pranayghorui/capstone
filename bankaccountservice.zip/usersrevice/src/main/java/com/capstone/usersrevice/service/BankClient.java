package com.capstone.usersrevice.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.capstone.usersrevice.entity.BankAccount;

@FeignClient (url="http://localhost:8082" , value="User-Client")
public interface BankClient {

	@GetMapping("/bankaccount/user/{userId}")
	List<BankAccount> getBankAccountOfUserId(@PathVariable("userId") int userId) ;
}
