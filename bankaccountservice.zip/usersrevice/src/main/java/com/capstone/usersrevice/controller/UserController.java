package com.capstone.usersrevice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.usersrevice.entity.User;
import com.capstone.usersrevice.service.UserService;

@RestController 
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;

	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	@PostMapping 
	public void createUser(@RequestBody User user) {
		userService.createUser(user);
	}
	
	@GetMapping
	public List<User> findAll(){
		return userService.findAll();
	}
	
	@GetMapping("/{id}")
	public User getById(@PathVariable int id) {
		return userService.getById(id);
	}
	
	@DeleteMapping("/{id}")
	public void deleteById(@PathVariable int id) {
		userService.deleteById(id);
	}
	
}
