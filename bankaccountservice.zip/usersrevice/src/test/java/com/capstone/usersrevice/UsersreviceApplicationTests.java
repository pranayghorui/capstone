package com.capstone.usersrevice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersreviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
