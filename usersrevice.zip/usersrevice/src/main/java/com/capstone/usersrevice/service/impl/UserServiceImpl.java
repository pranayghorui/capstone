package com.capstone.usersrevice.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstone.usersrevice.entity.User;
import com.capstone.usersrevice.repo.UserRepo;
import com.capstone.usersrevice.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo userRepo;
	@Override
	public void createUser(User user) {
		userRepo.save(user);
	}

	@Override
	public List<User> findAll() {
		return userRepo.findAll();
	}

	@Override
	public User getById(int id) {
		return userRepo.findById(id).get();
	}

	@Override
	public void deleteById(int id) {
		userRepo.deleteById(id);
	}

	@Override
	public User getByUserAcId(String userAcId) {
		return userRepo.getByUserAcId(userAcId);
	}
	
	

}
