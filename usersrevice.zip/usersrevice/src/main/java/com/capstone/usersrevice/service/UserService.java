package com.capstone.usersrevice.service;

import java.util.List;

import com.capstone.usersrevice.entity.User;

public interface UserService {

	void createUser(User user);
	
	List<User> findAll();
	
	User getById(int id);
	
	void deleteById(int id);
	
	User getByUserAcId(String userAcId);
	
}
