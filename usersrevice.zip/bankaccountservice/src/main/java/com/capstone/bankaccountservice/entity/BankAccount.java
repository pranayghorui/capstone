package com.capstone.bankaccountservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;

@Entity
@Table(name="bankdetails")
public class BankAccount {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(name="acc_num")
	private String accountNumber;
	@Column(name="acc_type")
	private String accountType;
	@Column(name="user_id")
	private int userId;
//	private String userAcId;
	
//	public String getUserAcId() {
//		return userAcId;
//	}
//
//	public void setUserAcId(String userAcId) {
//		this.userAcId = userAcId;
//	}

	public BankAccount() {
		super();
	}
	
	public BankAccount(int id, String accountNumber, String accountType, int userId) {
		this.id = id;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.userId = userId;
//		this.userAcId = userAcId;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

}

