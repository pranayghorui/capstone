package com.capstone.bankaccountservice.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capstone.bankaccountservice.entity.BankAccount;
import com.capstone.bankaccountservice.repo.BankAccountRepo;
import com.capstone.bankaccountservice.service.BankAccountService;

@Service
public class BankAccountServiceImpl implements BankAccountService {

	@Autowired
	private BankAccountRepo bankAccountRepo;

	public BankAccountServiceImpl(BankAccountRepo bankAccountRepo) {
//		super();
		this.bankAccountRepo = bankAccountRepo;
	}

	@Override
	public void createBankAccount(BankAccount bankAccount) {
		bankAccountRepo.save(bankAccount);		
	}

	@Override
	public List<BankAccount> findAll() {
		return bankAccountRepo.findAll();
	}

	@Override
//	public BankAccount getById(int id) {
//		return bankAccountRepo.findById(id).get();
//	}
	public BankAccount getById(int id) {
		return bankAccountRepo.findById(id).orElseThrow(() -> new RuntimeException("Bank Account not found"));
	}
	
	@Override
	public void deleteById(int id) {
		bankAccountRepo.deleteById(id);		
	}

	@Override
	public List<BankAccount> getBankAcOfUserId(int userId) {
		return bankAccountRepo.findByUserId(userId);
	}
}
