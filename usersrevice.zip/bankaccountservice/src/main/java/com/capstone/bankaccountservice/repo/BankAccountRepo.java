package com.capstone.bankaccountservice.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstone.bankaccountservice.entity.BankAccount;

@Repository
public interface BankAccountRepo extends JpaRepository<BankAccount, Integer>{
//	BankAccount findByUserAcId(String userAcId);
	List<BankAccount> findByUserId(int userId);
}
