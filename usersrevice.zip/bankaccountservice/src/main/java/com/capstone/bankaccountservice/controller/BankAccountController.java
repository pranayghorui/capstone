package com.capstone.bankaccountservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.bankaccountservice.entity.BankAccount;
import com.capstone.bankaccountservice.service.BankAccountService;

@RestController 
@RequestMapping("/bankaccount")
public class BankAccountController {
	
	@Autowired
	BankAccountService bankAccountService;

	public BankAccountController(BankAccountService bankAccountService) {
		this.bankAccountService = bankAccountService;
	}
	
	@PostMapping
	public void create(@RequestBody BankAccount bankAccount) {
		bankAccountService.createBankAccount(bankAccount);;
	}
	
	@GetMapping
	public List<BankAccount> findAll(){
		return bankAccountService.findAll();		
	}
	
	@GetMapping("{id}")
	public BankAccount getById(@PathVariable int id) {
		return bankAccountService.getById(id);
	}
	
	@DeleteMapping("/{id}")
	public void deleteById(@PathVariable int id) {
		bankAccountService.deleteById(id);
	}
	
	@GetMapping("/user/{userId}")
	public List<BankAccount> getBankAcOfUserId(@PathVariable("userId") int userId){
		return bankAccountService.getBankAcOfUserId(userId);
	}
	
}
